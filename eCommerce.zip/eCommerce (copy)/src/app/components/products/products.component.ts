import { Component, OnInit } from '@angular/core';
import { ProductService } from './../../services/product.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})


export class ProductsComponent implements OnInit {

  products:any;
  selectedProduct:any={};

  constructor(private productService:ProductService,private modalService: NgbModal) {
   
   }


  loadProducts(){
    this.products=this.productService.getProducts();
  }

  open(content:any,product:object) {
    console.log(product);
    this.selectedProduct=product;
    this.modalService.open(content);
  }


  ngOnInit(): void {
    this.loadProducts();
  }

}
