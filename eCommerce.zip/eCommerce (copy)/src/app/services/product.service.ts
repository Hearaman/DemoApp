import { Injectable } from '@angular/core';

import products from './../data/MOCK_DATA.json';


@Injectable()
export class ProductService {
  constructor () {}

  getProducts() {
    return products;
  }

}
